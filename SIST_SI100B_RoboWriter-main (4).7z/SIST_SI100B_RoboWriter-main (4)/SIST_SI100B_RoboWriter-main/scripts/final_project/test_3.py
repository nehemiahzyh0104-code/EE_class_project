
#写字高度，在这个高度以下才记录轨迹点
write_limit=0.1
#笔画轨迹移动时间
move_time=0.5
#提笔轨迹移动时间
hang_time=0.5
# 轨迹点最小间距，避免冗余
min_dist=0.001
#运行总时长
sim_time=1000



import mujoco as mj
from mujoco.glfw import glfw
import numpy as np
import os
import scipy as sp

xml_path = '../../models/universal_robots_ur5e/scene.xml'
simend = sim_time
print_camera_config = 0

# For callback functions
button_left = False
button_middle = False
button_right = False
lastx = 0
lasty = 0

# UR5e关节限位（最小值，最大值），6关节对应
UR5E_JOINT_LIMITS = np.array([
    [-np.pi, np.pi],
    [-np.pi, np.pi],
    [-np.pi, np.pi],
    [-np.pi, np.pi],
    [-np.pi, np.pi],
    [-np.pi, np.pi]
])

# ===== 新增：统一管理末端site id（避免写死0导致控制/记录不是笔尖）=====
EE_SITE_ID = 0  # 若你的xml中site[0]确实是笔尖，可保持0；否则请改为正确site id

# ===== 新增：抬笔高度保护（避免移动时误画）=====
LIFT_Z = write_limit + 0.06   # 移动/过渡段时，至少抬到这个高度（可调：0.05~0.10）
APPROACH_Z = write_limit + 0.03  # 下笔前缓冲高度，避免一开始太低（可调）

# Helper function
def IK_controller(model, data, X_ref, q_pos):
    # ===== 改动：6D（位置+姿态）阻尼最小二乘IK，锁定笔尖朝下，避免奇异/翻腕 =====
    position_Q = data.site_xpos[EE_SITE_ID].copy()
    site_xmat = data.site_xmat[EE_SITE_ID].reshape(3, 3).copy()

    jacp = np.zeros((3, model.nv))
    jacr = np.zeros((3, model.nv))
    mj.mj_jacSite(model, data, jacp, jacr, EE_SITE_ID)

    # 位置误差
    dX_pos = (X_ref - position_Q) * 1.2

    # 姿态误差：末端Z轴对齐世界 -Z（笔尖向下）
    z_world_des = np.array([0.0, 0.0, -1.0])
    z_site = site_xmat[:, 2]
    dX_rot = np.cross(z_site, z_world_des) * 0.8

    J = np.vstack((jacp, jacr))
    dX = np.hstack((dX_pos, dX_rot))

    # 阻尼最小二乘
    damp = 1e-2
    JJt = J @ J.T
    dq = J.T @ np.linalg.solve(JJt + (damp**2) * np.eye(6), dX)

    # 限幅
    dq = np.clip(dq, -0.08, 0.08)
    q_new = q_pos + dq

    # 限位
    for i in range(len(q_new)):
        q_new[i] = np.clip(q_new[i], UR5E_JOINT_LIMITS[i, 0], UR5E_JOINT_LIMITS[i, 1])

    return q_new

def init_controller(model,data):
    pass

def controller(model, data):
    pass

def keyboard(window, key, scancode, act, mods):
    if act == glfw.PRESS and key == glfw.KEY_BACKSPACE:
        mj.mj_resetData(model, data)
        mj.mj_forward(model, data)

def mouse_button(window, button, act, mods):
    global button_left
    global button_middle
    global button_right

    button_left = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_LEFT) == glfw.PRESS)
    button_middle = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_MIDDLE) == glfw.PRESS)
    button_right = (glfw.get_mouse_button(
        window, glfw.MOUSE_BUTTON_RIGHT) == glfw.PRESS)

    glfw.get_cursor_pos(window)

def mouse_move(window, xpos, ypos):
    global lastx
    global lasty
    global button_left
    global button_middle
    global button_right

    dx = xpos - lastx
    dy = ypos - lasty
    lastx = xpos
    lasty = ypos

    if (not button_left) and (not button_middle) and (not button_right):
        return

    width, height = glfw.get_window_size(window)

    PRESS_LEFT_SHIFT = glfw.get_key(
        window, glfw.KEY_LEFT_SHIFT) == glfw.PRESS
    PRESS_RIGHT_SHIFT = glfw.get_key(
        window, glfw.KEY_RIGHT_SHIFT) == glfw.PRESS
    mod_shift = (PRESS_LEFT_SHIFT or PRESS_RIGHT_SHIFT)

    if button_right:
        if mod_shift:
            action = mj.mjtMouse.mjMOUSE_MOVE_H
        else:
            action = mj.mjtMouse.mjMOUSE_MOVE_V
    elif button_left:
        if mod_shift:
            action = mj.mjtMouse.mjMOUSE_ROTATE_H
        else:
            action = mj.mjtMouse.mjMOUSE_ROTATE_V
    else:
        action = mj.mjtMouse.mjMOUSE_ZOOM

    mj.mjv_moveCamera(model, action, dx/height,
                      dy/height, scene, cam)

def scroll(window, xoffset, yoffset):
    action = mj.mjtMouse.mjMOUSE_ZOOM
    mj.mjv_moveCamera(model, action, 0.0, -0.05 *
                      yoffset, scene, cam)

# Get the full path
dirname = os.path.dirname(__file__)
abspath = os.path.join(dirname + "/" + xml_path)
xml_path = abspath

# MuJoCo data structures
model = mj.MjModel.from_xml_path(xml_path)
data = mj.MjData(model)
cam = mj.MjvCamera()
opt = mj.MjvOption()

# Init GLFW
glfw.init()
window = glfw.create_window(1920, 1080, "Demo", None, None)
glfw.make_context_current(window)
glfw.swap_interval(1)

# initialize visualization data structures
mj.mjv_defaultCamera(cam)
mj.mjv_defaultOption(opt)
scene = mj.MjvScene(model, maxgeom=10000)
context = mj.MjrContext(model, mj.mjtFontScale.mjFONTSCALE_150.value)

# install GLFW callbacks
glfw.set_key_callback(window, keyboard)
glfw.set_cursor_pos_callback(window, mouse_move)
glfw.set_mouse_button_callback(window, mouse_button)
glfw.set_scroll_callback(window, scroll)

# Camera configuration
cam.azimuth =  179.8300000000001
cam.elevation =  87.16333333333334
cam.distance =  2.22
cam.lookat = np.array([ 0.29723477517870245 , 0.28277006411151073 , 0.6082647377843177 ])

# Initialize the controller
init_controller(model,data)

# Set the controller
mj.set_mjcb_control(controller)

# ===== 改动：初始位姿调整到更适合写字且初始笔尖更高，避免一开始“蹭纸” =====
init_qpos = np.array([-1.57, -1.15, 2.05, -2.45, -1.57, 0.0])
data.qpos[:] = init_qpos
cur_q_pos = init_qpos.copy()
mj.mj_forward(model, data)

# Trajectory visualization
traj_points = []
MAX_TRAJ = 5000
LINE_RGBA = np.array([1.0, 0.0, 0.0, 1.0])
MIN_DISTANCE = min_dist
WRITE_Z_THRESHOLD = write_limit

######################################
### 定义多个轨迹段 ###
class TrajectorySegment:
    def __init__(self, start_point, end_point, control_point=None, interp_type='linear', duration=3.0):
        self.start_point = np.array(start_point)
        self.end_point = np.array(end_point)
        self.control_point = np.array(control_point) if control_point is not None else None
        self.interp_type = interp_type
        self.duration = duration
        self.completed = False

# ===== 改动：把所有“移动段/过渡段”的控制点或起点高度抬高一点，避免移动时误画 =====
# 做法：不改你原有点的x/y，只在必要处把z提升到 >= LIFT_Z 或 >= APPROACH_Z
def _lift_point(p, zmin):
    p = np.array(p, dtype=float)
    if p[2] < zmin:
        p[2] = zmin
    return p

# 定义书写路径（在你原始列表基础上做“最小z修正”）
trajectory_segments = [
    # ========== 李 字 ==========
    TrajectorySegment(start_point=_lift_point([0.19, 0.5, 0.3], LIFT_Z), end_point=[-0.19, 0.5, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.19, 0.5, 0.1], end_point=[-0.08, 0.5, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.08, 0.5, 0.1], end_point=[-0.13, 0.52, 0.1], control_point=_lift_point([-0.08, 0.5, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.13, 0.52, 0.1], end_point=[-0.13, 0.47, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.13, 0.47, 0.1], end_point=[-0.13, 0.5, 0.1], control_point=_lift_point([-0.13, 0.47, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.13, 0.5, 0.1], end_point=[-0.19, 0.47, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.19, 0.47, 0.1], end_point=[-0.13, 0.5, 0.1], control_point=_lift_point([-0.19, 0.47, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.13, 0.5, 0.1], end_point=[-0.07, 0.47, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.07, 0.47, 0.1], end_point=[-0.17, 0.46, 0.1], control_point=_lift_point([-0.07, 0.47, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.17, 0.46, 0.1], end_point=[-0.10, 0.46, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.10, 0.46, 0.1], end_point=[-0.10, 0.46, 0.1], control_point=_lift_point([-0.10, 0.46, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.10, 0.46, 0.1], end_point=[-0.13, 0.45, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.13, 0.45, 0.1], end_point=[-0.13, 0.45, 0.1], control_point=_lift_point([-0.13, 0.45, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.13, 0.45, 0.1], end_point=[-0.13, 0.41, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.13, 0.41, 0.1], end_point=[-0.13, 0.41, 0.1], control_point=_lift_point([-0.13, 0.41, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.13, 0.41, 0.1], end_point=[-0.15, 0.41, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.15, 0.41, 0.1], end_point=[-0.19, 0.44, 0.1], control_point=_lift_point([-0.15, 0.41, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.19, 0.44, 0.1], end_point=[-0.08, 0.44, 0.1], interp_type='linear', duration=1.5),

    # 李 -> 文（抬高控制点，避免误画）
    TrajectorySegment(start_point=[-0.08, 0.44, 0.1], end_point=[-0.01, 0.52, 0.1], control_point=_lift_point([-0.08, 0.44, 0.3], LIFT_Z), interp_type='bezier', duration=2.0),

    # ========== 文 字 ==========
    TrajectorySegment(start_point=[-0.01, 0.52, 0.1], end_point=[0.01, 0.5, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.01, 0.5, 0.1], end_point=[-0.055, 0.49, 0.1], control_point=_lift_point([0.01, 0.5, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.055, 0.49, 0.1], end_point=[0.055, 0.49, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.055, 0.49, 0.1], end_point=[0.025, 0.49, 0.1], control_point=_lift_point([0.055, 0.49, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.025, 0.49, 0.1], end_point=[-0.05, 0.4, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[-0.05, 0.4, 0.1], end_point=[-0.025, 0.49, 0.1], control_point=_lift_point([-0.05, 0.4, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[-0.025, 0.49, 0.1], end_point=[0.05, 0.4, 0.1], interp_type='linear', duration=1.5),

    # 文 -> 恒（抬高控制点，避免误画）
    TrajectorySegment(start_point=[0.05, 0.4, 0.1], end_point=[0.095, 0.52, 0.1], control_point=_lift_point([0.05, 0.4, 0.3], LIFT_Z), interp_type='bezier', duration=2.0),

    # ========== 恒 字 ==========
    TrajectorySegment(start_point=[0.095, 0.52, 0.1], end_point=[0.095, 0.4, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.095, 0.4, 0.1], end_point=[0.08, 0.485, 0.1], control_point=_lift_point([0.095, 0.4, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.08, 0.485, 0.1], end_point=[0.075, 0.465, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.075, 0.465, 0.1], end_point=[0.105, 0.485, 0.1], control_point=_lift_point([0.075, 0.465, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.105, 0.485, 0.1], end_point=[0.112, 0.48, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.112, 0.48, 0.1], end_point=[0.115, 0.51, 0.1], control_point=_lift_point([0.112, 0.48, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.115, 0.51, 0.1], end_point=[0.185, 0.51, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.185, 0.51, 0.1], end_point=[0.125, 0.475, 0.1], control_point=_lift_point([0.185, 0.51, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.125, 0.475, 0.1], end_point=[0.125, 0.44, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.125, 0.44, 0.1], end_point=[0.175, 0.475, 0.1], control_point=_lift_point([0.125, 0.44, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.175, 0.475, 0.1], end_point=[0.175, 0.44, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.175, 0.44, 0.1], end_point=[0.125, 0.475, 0.1], control_point=_lift_point([0.175, 0.44, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.125, 0.475, 0.1], end_point=[0.175, 0.475, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.175, 0.475, 0.1], end_point=[0.125, 0.4575, 0.1], control_point=_lift_point([0.175, 0.475, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.125, 0.4575, 0.1], end_point=[0.175, 0.4575, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.175, 0.4575, 0.1], end_point=[0.125, 0.44, 0.1], control_point=_lift_point([0.175, 0.4575, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.125, 0.44, 0.1], end_point=[0.175, 0.44, 0.1], interp_type='linear', duration=1.5),
    TrajectorySegment(start_point=[0.175, 0.44, 0.1], end_point=[0.115, 0.415, 0.1], control_point=_lift_point([0.175, 0.44, 0.3], LIFT_Z), interp_type='bezier', duration=1.5),
    TrajectorySegment(start_point=[0.115, 0.415, 0.1], end_point=[0.185, 0.415, 0.1], interp_type='linear', duration=1.5),

    # ===== 恒 -> “2” 的移动：你这里原来就是突然跳到 [-0.331, 0.205, 0.3]
    # 为了避免途中误画：确保这一段起点抬高，且路径经过LIFT_Z以上
    TrajectorySegment(start_point=_lift_point([0.185, 0.415, 0.1], LIFT_Z), end_point=_lift_point([-0.331, 0.205, 0.3], LIFT_Z), interp_type='linear', duration=2.0),

    TrajectorySegment(start_point=_lift_point([-0.331, 0.205, 0.3], LIFT_Z), end_point=[-0.331, 0.205, 0.1], interp_type='linear', duration=2.0),
    TrajectorySegment(start_point=[-0.331, 0.205, 0.1], end_point=[-0.29, 0.181, 0.1], control_point=_lift_point([-0.3, 0.22, 0.1], APPROACH_Z), interp_type='bezier', duration=2.0),
    TrajectorySegment(start_point=[-0.29, 0.181, 0.1], end_point=[-0.29, 0.181, 0.1], control_point=_lift_point([-0.29, 0.181, 0.3], LIFT_Z), interp_type='bezier', duration=2.0),
    TrajectorySegment(start_point=[-0.29, 0.181, 0.1], end_point=[-0.33, 0.14, 0.1], interp_type='linear', duration=2.0),
]

# 轨迹执行状态
current_segment_index = 0
segment_start_time = 0.0
X_ref = trajectory_segments[0].start_point

######################################
### INTERPOLATION FUNCTIONS ###
def LinearInterpolate(q0, q1, t, t_total):
    u = t / t_total
    u = np.clip(u, 0, 1)
    u = np.sin(u * np.pi / 2)
    return q0 + u * (q1 - q0)

def QuadBezierInterpolate(q0, q1, q2, t, t_total):
    u = t / t_total
    u = np.clip(u, 0, 1)
    u = np.sin(u * np.pi / 2)
    return (1 - u)**2 * q0 + 2 * u * (1 - u) * q1 + u**2 * q2

def get_reference_position(current_time):
    global current_segment_index, segment_start_time, X_ref, trajectory_segments
    
    if current_segment_index >= len(trajectory_segments):
        return trajectory_segments[-1].end_point
    
    current_segment = trajectory_segments[current_segment_index]
    segment_elapsed_time = current_time - segment_start_time
    
    if segment_elapsed_time >= current_segment.duration:
        current_segment.completed = True
        X_ref = current_segment.end_point
        current_segment_index += 1
        
        if current_segment_index < len(trajectory_segments):
            segment_start_time = current_time
            current_segment = trajectory_segments[current_segment_index]
            X_ref = current_segment.start_point
    
    if current_segment.interp_type == 'linear':
        X_ref = LinearInterpolate(
            current_segment.start_point,
            current_segment.end_point,
            segment_elapsed_time,
            current_segment.duration
        )
    elif current_segment.interp_type == 'bezier' and current_segment.control_point is not None:
        X_ref = QuadBezierInterpolate(
            current_segment.start_point,
            current_segment.control_point,
            current_segment.end_point,
            segment_elapsed_time,
            current_segment.duration
        )
    
    return X_ref
############################################

while not glfw.window_should_close(window):
    time_prev = data.time

    while (data.time - time_prev < 1.0/60.0):
        # Store trajectory：z≤阈值才记录
        mj_end_eff_pos = data.site_xpos[EE_SITE_ID]
        if mj_end_eff_pos[2] <= WRITE_Z_THRESHOLD:
            if len(traj_points) == 0:
                traj_points.append(mj_end_eff_pos.copy())
            else:
                last_point = traj_points[-1]
                dist = np.linalg.norm(mj_end_eff_pos - last_point)
                if dist >= MIN_DISTANCE:
                    traj_points.append(mj_end_eff_pos.copy())
        if len(traj_points) > MAX_TRAJ:
            traj_points.pop(0)
            
        cur_q_pos = data.qpos.copy()
        X_ref = get_reference_position(data.time)

        # ===== 新增：额外保护——如果当前是“移动/空中”但参考z太低，则强制抬高 =====
        # 这样即便某段轨迹点写错了z，也不会误画
        if X_ref[2] > WRITE_Z_THRESHOLD and X_ref[2] < LIFT_Z:
            X_ref = X_ref.copy()
            X_ref[2] = LIFT_Z

        cur_ctrl = IK_controller(model, data, X_ref, cur_q_pos)
        data.ctrl[:] = cur_ctrl
        
        mj.mj_step(model, data)

    if (data.time >= simend):
        break

    viewport_width, viewport_height = glfw.get_framebuffer_size(window)
    viewport = mj.MjrRect(0, 0, viewport_width, viewport_height)

    if (print_camera_config==1):
        print('cam.azimuth = ', cam.azimuth, '\n', 'cam.elevation = ', cam.elevation, '\n', 'cam.distance = ', cam.distance)
        print('cam.lookat = np.array([', cam.lookat[0], ',', cam.lookat[1], ',', cam.lookat[2], '])')

    mj.mjv_updateScene(model, data, opt, None, cam,
                       mj.mjtCatBit.mjCAT_ALL.value, scene)
    
    for j in range(len(traj_points)):
        if scene.ngeom >= scene.maxgeom:
            break
        geom = scene.geoms[scene.ngeom]
        scene.ngeom += 1
        geom.type = mj.mjtGeom.mjGEOM_SPHERE
        geom.rgba[:] = LINE_RGBA
        geom.size[:] = np.array([0.002, 0.002, 0.002])
        geom.pos[:] = traj_points[j]
        geom.mat[:] = np.eye(3)
        geom.dataid = -1
        geom.segid = -1
        geom.objtype = 0
        geom.objid = 0
        
    for i, segment in enumerate(trajectory_segments):
        if scene.ngeom >= scene.maxgeom:
            break
            
        geom = scene.geoms[scene.ngeom]
        scene.ngeom += 1
        geom.type = mj.mjtGeom.mjGEOM_SPHERE
        geom.rgba[:] = np.array([0.0, 1.0, 0.0, 1.0])
        geom.size[:] = np.array([0.005, 0.005, 0.005])
        geom.pos[:] = segment.start_point
        geom.mat[:] = np.eye(3)
        geom.dataid = -1
        geom.segid = -1
        geom.objtype = 0
        geom.objid = 0
        
        if scene.ngeom >= scene.maxgeom:
            break
            
        geom = scene.geoms[scene.ngeom]
        scene.ngeom += 1
        geom.type = mj.mjtGeom.mjGEOM_SPHERE
        geom.rgba[:] = np.array([0.0, 0.0, 1.0, 1.0])
        geom.size[:] = np.array([0.005, 0.005, 0.005])
        geom.pos[:] = segment.end_point
        geom.mat[:] = np.eye(3)
        geom.dataid = -1
        geom.segid = -1
        geom.objtype = 0
        geom.objid = 0
        
        if segment.interp_type == 'bezier' and segment.control_point is not None:
            if scene.ngeom >= scene.maxgeom:
                break
            geom = scene.geoms[scene.ngeom]
            scene.ngeom += 1
            geom.type = mj.mjtGeom.mjGEOM_SPHERE
            geom.rgba[:] = np.array([1.0, 1.0, 0.0, 1.0])
            geom.size[:] = np.array([0.004, 0.004, 0.004])
            geom.pos[:] = segment.control_point
            geom.mat[:] = np.eye(3)
            geom.dataid = -1
            geom.segid = -1
            geom.objtype = 0
            geom.objid = 0
    
    mj.mjr_render(viewport, scene, context)
    glfw.swap_buffers(window)
    glfw.poll_events()

glfw.terminate()
